<?php

/* base.html.twig */
class __TwigTemplate_ca8c494eccae25ead8c68766da086b219e40e54c74890846224f1797aa793654 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8500206be9f65be0eeadcefbf7ef39dcac5cef1c7ca51c390966c70f4a2ab275 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8500206be9f65be0eeadcefbf7ef39dcac5cef1c7ca51c390966c70f4a2ab275->enter($__internal_8500206be9f65be0eeadcefbf7ef39dcac5cef1c7ca51c390966c70f4a2ab275_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>";
        // line 11
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\"/>
</head>

<body id=\"";
        // line 19
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">

";
        // line 21
        $this->displayBlock('header', $context, $blocks);
        // line 39
        echo "
<div class=\"container body-container\">
    ";
        // line 41
        $this->displayBlock('body', $context, $blocks);
        // line 48
        echo "</div>


";
        // line 51
        $this->displayBlock('javascripts', $context, $blocks);
        // line 57
        echo "
</body>
</html>
";
        
        $__internal_8500206be9f65be0eeadcefbf7ef39dcac5cef1c7ca51c390966c70f4a2ab275->leave($__internal_8500206be9f65be0eeadcefbf7ef39dcac5cef1c7ca51c390966c70f4a2ab275_prof);

    }

    // line 11
    public function block_title($context, array $blocks = array())
    {
        $__internal_c04af335e63ad4873929af6f499fdb5d99964d80d98f015f34c47b6e167ad42c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c04af335e63ad4873929af6f499fdb5d99964d80d98f015f34c47b6e167ad42c->enter($__internal_c04af335e63ad4873929af6f499fdb5d99964d80d98f015f34c47b6e167ad42c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Calculator";
        
        $__internal_c04af335e63ad4873929af6f499fdb5d99964d80d98f015f34c47b6e167ad42c->leave($__internal_c04af335e63ad4873929af6f499fdb5d99964d80d98f015f34c47b6e167ad42c_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_d3a020c5a7c99fbb94dbb087dc72da21c7c3f141f18c423d80ecf0c1cd765f36 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d3a020c5a7c99fbb94dbb087dc72da21c7c3f141f18c423d80ecf0c1cd765f36->enter($__internal_d3a020c5a7c99fbb94dbb087dc72da21c7c3f141f18c423d80ecf0c1cd765f36_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 13
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap-datetimepicker.min.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_d3a020c5a7c99fbb94dbb087dc72da21c7c3f141f18c423d80ecf0c1cd765f36->leave($__internal_d3a020c5a7c99fbb94dbb087dc72da21c7c3f141f18c423d80ecf0c1cd765f36_prof);

    }

    // line 19
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_fa42e894ef13c82f546bbfff0f74275a4ca2683638d220504827326873e32244 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fa42e894ef13c82f546bbfff0f74275a4ca2683638d220504827326873e32244->enter($__internal_fa42e894ef13c82f546bbfff0f74275a4ca2683638d220504827326873e32244_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_fa42e894ef13c82f546bbfff0f74275a4ca2683638d220504827326873e32244->leave($__internal_fa42e894ef13c82f546bbfff0f74275a4ca2683638d220504827326873e32244_prof);

    }

    // line 21
    public function block_header($context, array $blocks = array())
    {
        $__internal_d1e792f581146c2a394670accd93cf7914c7851b360718a71252c2175ccc01d9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d1e792f581146c2a394670accd93cf7914c7851b360718a71252c2175ccc01d9->enter($__internal_d1e792f581146c2a394670accd93cf7914c7851b360718a71252c2175ccc01d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 22
        echo "    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("index");
        echo "\" class=\"navbar-brand\">CALCULATOR</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>

            </div>
        </div>
    </header>
";
        
        $__internal_d1e792f581146c2a394670accd93cf7914c7851b360718a71252c2175ccc01d9->leave($__internal_d1e792f581146c2a394670accd93cf7914c7851b360718a71252c2175ccc01d9_prof);

    }

    // line 41
    public function block_body($context, array $blocks = array())
    {
        $__internal_9ac5eb04921a48c87bbdd2827bac636ea6230039dc0d0cf3b86ded4b6c4e7284 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9ac5eb04921a48c87bbdd2827bac636ea6230039dc0d0cf3b86ded4b6c4e7284->enter($__internal_9ac5eb04921a48c87bbdd2827bac636ea6230039dc0d0cf3b86ded4b6c4e7284_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 42
        echo "        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                ";
        // line 44
        $this->displayBlock('main', $context, $blocks);
        // line 45
        echo "            </div>
        </div>
    ";
        
        $__internal_9ac5eb04921a48c87bbdd2827bac636ea6230039dc0d0cf3b86ded4b6c4e7284->leave($__internal_9ac5eb04921a48c87bbdd2827bac636ea6230039dc0d0cf3b86ded4b6c4e7284_prof);

    }

    // line 44
    public function block_main($context, array $blocks = array())
    {
        $__internal_5032ec39095dcab4034f9bcb5ce8a92e218215adb7bbca3ec1e21d2522585dca = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5032ec39095dcab4034f9bcb5ce8a92e218215adb7bbca3ec1e21d2522585dca->enter($__internal_5032ec39095dcab4034f9bcb5ce8a92e218215adb7bbca3ec1e21d2522585dca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_5032ec39095dcab4034f9bcb5ce8a92e218215adb7bbca3ec1e21d2522585dca->leave($__internal_5032ec39095dcab4034f9bcb5ce8a92e218215adb7bbca3ec1e21d2522585dca_prof);

    }

    // line 51
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_fe138cd79ff28b54c020db5382c482af07330480fd152ea8c5cb59aac5807bbc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fe138cd79ff28b54c020db5382c482af07330480fd152ea8c5cb59aac5807bbc->enter($__internal_fe138cd79ff28b54c020db5382c482af07330480fd152ea8c5cb59aac5807bbc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 52
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/jquery-2.2.4.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 53
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/moment.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 54
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 55
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap-datetimepicker.min.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_fe138cd79ff28b54c020db5382c482af07330480fd152ea8c5cb59aac5807bbc->leave($__internal_fe138cd79ff28b54c020db5382c482af07330480fd152ea8c5cb59aac5807bbc_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  205 => 55,  201 => 54,  197 => 53,  192 => 52,  186 => 51,  175 => 44,  166 => 45,  164 => 44,  160 => 42,  154 => 41,  134 => 26,  128 => 22,  122 => 21,  111 => 19,  102 => 14,  97 => 13,  91 => 12,  79 => 11,  69 => 57,  67 => 51,  62 => 48,  60 => 41,  56 => 39,  54 => 21,  49 => 19,  42 => 16,  40 => 12,  36 => 11,  29 => 6,);
    }

    public function getSource()
    {
        return "{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>{% block title %}Calculator{% endblock %}</title>
    {% block stylesheets %}
        <link rel=\"stylesheet\" href=\"{{ asset('css/style.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap-datetimepicker.min.css') }}\">
    {% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\"/>
</head>

<body id=\"{% block body_id %}{% endblock %}\">

{% block header %}
    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"{{ path('index') }}\" class=\"navbar-brand\">CALCULATOR</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>

            </div>
        </div>
    </header>
{% endblock %}

<div class=\"container body-container\">
    {% block body %}
        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                {% block main %}{% endblock %}
            </div>
        </div>
    {% endblock %}
</div>


{% block javascripts %}
    <script src=\"{{ asset('js/jquery-2.2.4.min.js') }}\"></script>
    <script src=\"{{ asset('js/moment.min.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap-datetimepicker.min.js') }}\"></script>
{% endblock %}

</body>
</html>
";
    }
}
