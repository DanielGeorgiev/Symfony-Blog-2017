<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_09803babd3e2c7bb3a6e17e3a348b9832ecc89ca293544de25936f4e2155b47a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_97a0396bb3ac60a6ad79e4f2d4b073e0cf93c86a8557d4c02cfcc56c074b4b0b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_97a0396bb3ac60a6ad79e4f2d4b073e0cf93c86a8557d4c02cfcc56c074b4b0b->enter($__internal_97a0396bb3ac60a6ad79e4f2d4b073e0cf93c86a8557d4c02cfcc56c074b4b0b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_97a0396bb3ac60a6ad79e4f2d4b073e0cf93c86a8557d4c02cfcc56c074b4b0b->leave($__internal_97a0396bb3ac60a6ad79e4f2d4b073e0cf93c86a8557d4c02cfcc56c074b4b0b_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_031bb64860ad58ebb0a932f349fd5ab15d1d4d228d95470c1759fe06963eef33 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_031bb64860ad58ebb0a932f349fd5ab15d1d4d228d95470c1759fe06963eef33->enter($__internal_031bb64860ad58ebb0a932f349fd5ab15d1d4d228d95470c1759fe06963eef33_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_031bb64860ad58ebb0a932f349fd5ab15d1d4d228d95470c1759fe06963eef33->leave($__internal_031bb64860ad58ebb0a932f349fd5ab15d1d4d228d95470c1759fe06963eef33_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_341df90b6e79a84281a4ee4d36f63c76ed299fe0601f0504bcdb4252c9e2dd6c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_341df90b6e79a84281a4ee4d36f63c76ed299fe0601f0504bcdb4252c9e2dd6c->enter($__internal_341df90b6e79a84281a4ee4d36f63c76ed299fe0601f0504bcdb4252c9e2dd6c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_341df90b6e79a84281a4ee4d36f63c76ed299fe0601f0504bcdb4252c9e2dd6c->leave($__internal_341df90b6e79a84281a4ee4d36f63c76ed299fe0601f0504bcdb4252c9e2dd6c_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_5812b61392d86a843f51ca92f5c8190d93a0ce60ff111a50e07299b72c565fce = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5812b61392d86a843f51ca92f5c8190d93a0ce60ff111a50e07299b72c565fce->enter($__internal_5812b61392d86a843f51ca92f5c8190d93a0ce60ff111a50e07299b72c565fce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_5812b61392d86a843f51ca92f5c8190d93a0ce60ff111a50e07299b72c565fce->leave($__internal_5812b61392d86a843f51ca92f5c8190d93a0ce60ff111a50e07299b72c565fce_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
";
    }
}
